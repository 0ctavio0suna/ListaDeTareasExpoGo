import { View, Text } from "react-native";

export const Tasks =()=>{
    return(
        <View>
            <Text>Tarea 1</Text>
            <Text>Tarea 2</Text>
            <Text>Tarea 3</Text>
        </View>
    )
}